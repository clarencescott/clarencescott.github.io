document.getElementById('add-folder-btn').addEventListener('click', addFolder);
document.getElementById('add-subfolder-btn').addEventListener('click', addSubfolder);
document.getElementById('add-file-btn').addEventListener('click', addFile);
document.getElementById('generate-btn').addEventListener('click', generateFolderStructure);
document.getElementById('save-btn').addEventListener('click', saveStructure);
document.getElementById('clear-btn').addEventListener('click', clearInputs);

let folders = [];
let stagedFiles = [];

function addFolder() {
    const folderName = document.getElementById('folder-name').value.trim();
    if (folderName) {
        const folder = { name: folderName, files: [], subfolders: [] };
        folders.push(folder);
        updateFolderSelect();
        updateFileLocationSelect();
        document.getElementById('folder-name').value = ''; // Clear input
    }
}

function addSubfolder() {
    const subfolderName = document.getElementById('subfolder-name').value.trim();
    const folderSelect = document.getElementById('folder-select');
    const parentFolderName = folderSelect.value;

    if (subfolderName && parentFolderName) {
        const parentFolder = folders.find(f => f.name === parentFolderName);
        const subfolder = { name: subfolderName, files: [] };
        parentFolder.subfolders.push(subfolder);
        updateFileLocationSelect();
        updatePreview();
        document.getElementById('subfolder-name').value = ''; // Clear input
    } else {
        alert("Please select a folder and enter a subfolder name.");
    }
}

function addFile() {
    const fileName = document.getElementById('file-name').value.trim();
    const fileLocationSelect = document.getElementById('file-location-select');
    const location = fileLocationSelect.value;

    if (fileName && location) {
        if (isValidFile(fileName)) {
            const [folderName, subfolderName] = location.split('/');
            const fileLocation = { fileName, folderName, subfolderName };

            stagedFiles.push(fileLocation);
            updateStagedFiles();
            document.getElementById('file-name').value = ''; // Clear input
        } else {
            alert("Please enter a valid file name with extension.");
        }
    } else {
        alert("Please select a valid folder or subfolder.");
    }
}

function isValidFile(fileName) {
    const regex = /^[\w-]+\.(html|js|css|md)$/;  // Simple validation for file types
    return regex.test(fileName);
}

function updateFolderSelect() {
    const folderSelect = document.getElementById('folder-select');
    folderSelect.innerHTML = '<option value="">Select Folder for Subfolder</option>';  // Reset options
    folders.forEach(folder => {
        const option = document.createElement('option');
        option.value = folder.name;
        option.textContent = folder.name;
        folderSelect.appendChild(option);
    });
}

function updateFileLocationSelect() {
    const fileLocationSelect = document.getElementById('file-location-select');
    fileLocationSelect.innerHTML = '<option value="">Select Folder/Subfolder for File</option>'; // Reset options

    // Add main folders
    folders.forEach(folder => {
        const option = document.createElement('option');
        option.value = folder.name;
        option.textContent = folder.name;
        fileLocationSelect.appendChild(option);

        // Add subfolders
        folder.subfolders.forEach(subfolder => {
            const subfolderOption = document.createElement('option');
            subfolderOption.value = `${folder.name}/${subfolder.name}`;
            subfolderOption.textContent = `${folder.name} > ${subfolder.name}`;
            fileLocationSelect.appendChild(subfolderOption);
        });
    });
}

function updateStagedFiles() {
    const stagedFilesList = document.getElementById('staged-files-list');
    stagedFilesList.innerHTML = '';
    stagedFiles.forEach((file, index) => {
        const listItem = document.createElement('li');
        listItem.textContent = `${file.fileName} (Location: ${file.folderName}/${file.subfolderName || 'None'})`;
        stagedFilesList.appendChild(listItem);
    });
}

function generateFolderStructure() {
    // Assign staged files to the selected folder and subfolder
    folders.forEach(folder => {
        folder.files = [];
        stagedFiles.forEach(file => {
            if (file.folderName === folder.name) {
                if (file.subfolderName) {
                    const subfolder = folder.subfolders.find(sub => sub.name === file.subfolderName);
                    if (subfolder) subfolder.files.push(file.fileName);
                } else {
                    folder.files.push(file.fileName);
                }
            }
        });
    });

    updatePreview();
}

function updatePreview() {
    let previewText = '';
    folders.forEach(folder => {
        previewText += `Folder: ${folder.name}\n`;
        folder.files.forEach(file => {
            previewText += `  - ${file}\n`;
        });
        folder.subfolders.forEach(subfolder => {
            previewText += `  Subfolder: ${subfolder.name}\n`;
            subfolder.files.forEach(file => {
                previewText += `    - ${file}\n`;
            });
        });
        previewText += '\n';
    });

    document.getElementById('preview-area').textContent = previewText;
}

function saveStructure() {
    const zip = new JSZip();

    // Add folders and files to the ZIP
    folders.forEach(folder => {
        const folderFolder = zip.folder(folder.name);
        folder.files.forEach(file => {
            folderFolder.file(file, ""); // Create empty files for now
        });
        folder.subfolders.forEach(subfolder => {
            const subfolderFolder = folderFolder.folder(subfolder.name);
            subfolder.files.forEach(file => {
                subfolderFolder.file(file, ""); // Create empty files for now
            });
        });
    });

    // Generate and download ZIP file
    zip.generateAsync({ type: 'blob' }).then(function(content) {
        const a = document.createElement('a');
        a.href = URL.createObjectURL(content);
        a.download = 'folder-structure.zip';
        a.click();
    });
}

function clearInputs() {
    document.getElementById('folder-name').value = '';
    document.getElementById('subfolder-name').value = '';
    document.getElementById('file-name').value = '';
    stagedFiles = [];
    updateStagedFiles();
}

